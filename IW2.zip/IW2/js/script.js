// aula de hoje função
// 1 nomeada
"10", "20"

function Aluno(){
    alert('Olá sou ?');
    console.log('teste de debug');
}
// 2 nomeada com parametro
function Aluno(nome){
    alert('Olá sou ' + nome);
    console.log('teste de debug');
}
// chamar a função
//Aluno();

//função nomeada, parâmetro(s), retorno
"10", "20"
// pegar referencia do DOM TAG SPAN
let tagSpan = document.querySelector("span");

function NoRePar (parm01, parm02){
   
    let numero = parseFloat(parm01) + parseFloat(parm02);
    return numero;//apenas um valor ou outro array

}
    tagSpan.innerHTML = NoRePar(10, 50);