// aula de hoje função
// 1 nomeada
"10", "20", arg1, arg2

function Aluno(){
    alert('Olá sou ?');
    console.log('teste de debug');
}
// 2 nomeada com parametro
function Aluno(nome){
    alert('Olá sou ' + nome);
    console.log('teste de debug');
}
// chamar a função
//Aluno();

//função nomeada, parâmetro(s), retorno
"10", "20"
// pegar referencia do DOM TAG SPAN
let tagSpan = document.querySelector("span");

function NoRePar (parm01, parm02){
   
    let numero = parseFloat(parm01) + parseFloat(parm02);
    return numero;//apenas um valor ou outro array

}
    tagSpan.innerHTML = NoRePar(10, 50);

//1função nomeada e argumento
function NomeF(arg1, arg2){

        return arg1+ arg2
        /* retorno somente um valor
        por vez, variavel ou array */
}
var vF = new Function"('arg', 'arg1', "alert("Ola" + arg + )")";

let ms = function(){
    console.log()
}