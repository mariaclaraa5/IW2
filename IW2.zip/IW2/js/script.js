// 1° função nomeada
function Aluno() {
    alert('Olá, sou?');
    console.log('Teste de debug');
}

function Alunos(nome) {
    alert('Olá, sou? ' + nome);
    console.log('Teste de debug');
}

// 1º função nomeada e argumento
function NomeF(arg1, arg2) {
    return arg1 + arg2; // Retorna um valor, array ou variável
}

// 2º função usando Function corretamente
let vF = new Function('arg1', 'arg2', 'alert("Olá " + arg1 + ", " + arg2)');

// 3º forma corrigida
let ms = function (n, n2) {
    console.log('3ª forma da função');
    let result = parseFloat(n) + parseFloat(n2);
    return result;
};

// Executando a função ms com os números 10 e 5 e exibindo no console
let resultado = ms(10, 5);
//console.log("Resultado: " + resultado);

//arrow function
//nomeada/ variavel 
let arrow01 = () => {
 alert('exemplo 01') 

}
let arrow02 =() =>{
    alert('exemplo 02');
}

